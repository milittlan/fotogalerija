<div class="admin-top-bar">
    <div class="container" >
        <li><a href="admin/logout.php">Logout</a></li>
        <li><a href="admin/index.php">Administracija</a></li>
    </div>
</div>
