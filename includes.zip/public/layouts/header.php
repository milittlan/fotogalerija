<html>
  <head>
    <title>Foto galerija</title>
    <link href="stylesheets/bootstrap.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/main.css" media="all" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <div id="header">
      <h1>Foto galerija</h1>
    </div>
    <div id="main">
        <div class="container">
