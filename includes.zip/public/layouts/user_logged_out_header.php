<div class="admin-top-bar">
    <div class="container" >
        <li><a href="admin/login.php">Login</a></li>
    </div>
</div>
