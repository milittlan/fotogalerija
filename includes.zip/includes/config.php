<?php

// Database constants

define('DB_SERVER') ? null : define("DB_SERVER", "localhost");
define('DB_USER') ? null : define("DB_USER", "milanbil_gallery");
define('DB_PASS') ? null : define("DB_PASS", "D58NG~eTvQo;");
define('DB_NAME') ? null : define("DB_NAME", "milanbil_photo_gallery");

?>